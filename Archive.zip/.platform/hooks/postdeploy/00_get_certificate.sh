#!/usr/bin/env bash
# Place in .platform/hooks/postdeploy directory
sudo certbot -n -d Intex-1-11-env.eba-c3aknxa8.us-east-1.elasticbeanstalk.com --nginx --agree-tos --email sab716@byu.edu