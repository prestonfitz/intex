#!/usr/bin/env bash
# Place in .platform/hooks/postdeploy directory
sudo certbot -n -d mentalhealthprovo.is404.net --nginx --agree-tos --email sab716@byu.edu